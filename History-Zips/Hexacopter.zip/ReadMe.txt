Product: Hexacopter, September 2014

Designer: Jens Dyvik, http://www.dyvikdesign.com/

Support:  support@obrary.com

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
This design is for a hexacopter from and propellers. 